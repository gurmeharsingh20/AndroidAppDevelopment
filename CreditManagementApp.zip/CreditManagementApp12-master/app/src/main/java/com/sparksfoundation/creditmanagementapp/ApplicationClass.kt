package com.sparksfoundation.creditmanagementapp

import android.app.Application
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.initializeInstance

class ApplicationClass : Application() {
    override fun onCreate() {
        super.onCreate()
        initializeInstance(DatabaseHelper(applicationContext))
    }
}