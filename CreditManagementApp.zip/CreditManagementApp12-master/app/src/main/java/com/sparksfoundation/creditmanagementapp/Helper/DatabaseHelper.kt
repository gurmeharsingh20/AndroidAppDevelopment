package com.sparksfoundation.creditmanagementapp.Helper

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns

class DatabaseHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    private val TABLE_USER_DROP = "DROP TABLE IF EXISTS $TABLE_USERS"
    private val TABLE_TRANSACTION_DROP = "DROP TABLE IF EXISTS $TABLE_TRANSACTIONS"
    private val TABLE_CREATE_USER = "CREATE TABLE " + TABLE_USERS + " (" +
            KEY_ID + " INTEGER PRIMARY KEY, " +
            KEY_NAME + " TEXT UNIQUE, " +
            KEY_EMAIL + " TEXT UNIQUE, " +
            KEY_CURRENT_CREDITS + " INTEGER);"
    private val TABLE_CREATE_TRANSACTION = "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
            KEY_ID + " INTEGER PRIMARY KEY, " +
            KEY_DATE_TIME + " TEXT, " +
            KEY_SENDER_ID + " INTEGER, " +
            KEY_RECEIVER_ID + " INTEGER, " +
            KEY_SENDER_OPENING_BALANCE + " INTEGER, " +
            KEY_SENDER_CLOSING_BALANCE + " INTEGER, " +
            KEY_RECEIVER_OPENING_BALANCE + " INTEGER, " +
            KEY_RECEIVER_CLOSING_BALANCE + " INTEGER, " +
            KEY_ORDER_STATUS + " TEXT);"

    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(TABLE_CREATE_USER)
        sqLiteDatabase.execSQL(TABLE_CREATE_TRANSACTION)
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {}
    fun dropDatabase(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(TABLE_USER_DROP)
        sqLiteDatabase.execSQL(TABLE_CREATE_USER)
        sqLiteDatabase.execSQL(TABLE_TRANSACTION_DROP)
        sqLiteDatabase.execSQL(TABLE_CREATE_TRANSACTION)
    }

    companion object {
        private const val DATABASE_NAME = "CreditManagement.sqlite"
        private const val DATABASE_VERSION = 1
        const val TABLE_USERS = "users"
        const val TABLE_TRANSACTIONS = "transactions"

        // Common column names
        const val KEY_ID = BaseColumns._ID

        // Users Table - column names
        const val KEY_NAME = "name"
        const val KEY_EMAIL = "email"
        const val KEY_CURRENT_CREDITS = "current_credits"

        // Transactions Table - column names
        const val KEY_DATE_TIME = "date_time"
        const val KEY_SENDER_ID = "sender"
        const val KEY_RECEIVER_ID = "receiver"
        const val KEY_SENDER_OPENING_BALANCE = "sender_opening_balance"
        const val KEY_SENDER_CLOSING_BALANCE = "sender_closing_balance"
        const val KEY_RECEIVER_OPENING_BALANCE = "receiver_opening_balance"
        const val KEY_RECEIVER_CLOSING_BALANCE = "receiver_closing_balance"
        const val KEY_ORDER_STATUS = "order_status"
    }
}