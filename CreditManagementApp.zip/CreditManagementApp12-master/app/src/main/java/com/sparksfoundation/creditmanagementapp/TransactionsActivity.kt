package com.sparksfoundation.creditmanagementapp

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.ListView
import android.widget.Toast
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseManager.Companion.getInstance

class TransactionsActivity : AppCompatActivity() {
    lateinit var transactionsListView: ListView
    private var emptyView: View? = null
    private var mTransactionCursorAdapter: TransactionCursorAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transactions)
        transactionsListView = findViewById(R.id.transactions_list)
        emptyView = findViewById(R.id.empty_view)
        transactionsListView.setEmptyView(emptyView)
        mTransactionCursorAdapter = TransactionCursorAdapter(this, null)
        transactionsListView.setAdapter(mTransactionCursorAdapter)
        try {
            val dataFetchQuery = "SELECT * FROM " + DatabaseHelper.TABLE_TRANSACTIONS + ";"
            getInstance()!!.openDatabase()
            val cursor = getInstance()!!.getDetails(dataFetchQuery)
            if (cursor != null && cursor.count > 0) {
                showToast("No. of transactions :" + cursor.count)
            } else if (cursor.count == 0) {
                showToast("No Transaction")
            }
            mTransactionCursorAdapter!!.swapCursor(cursor)
        } catch (e: Exception) {
            showToast("Catch Block, error in fetching data")
            Log.i("TransactionsActivity", "Catch block error : ")
            e.printStackTrace()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLongToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}