package com.sparksfoundation.creditmanagementapp

import android.content.Context
import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CursorAdapter
import android.widget.TextView
import com.sparksfoundation.creditmanagementapp.Helper.DatabaseHelper

class TransactionCursorAdapter(context: Context?, c: Cursor?) : CursorAdapter(context, c, 0) {
    override fun newView(context: Context, cursor: Cursor, parent: ViewGroup): View {
        return LayoutInflater.from(context).inflate(R.layout.transaction_item, parent, false)
    }

    override fun bindView(view: View, context: Context, cursor: Cursor) {
        val transactionIdTextView = view.findViewById<TextView>(R.id.transaction_id)
        val transactionTimeTextView = view.findViewById<TextView>(R.id.transaction_time)
        val senderIdTextView = view.findViewById<TextView>(R.id.sender_id)
        val receiverIdTextView = view.findViewById<TextView>(R.id.receiver_id)
        val senderOpeningBalanceTextView = view.findViewById<TextView>(R.id.sender_opening_balance)
        val senderClosingBalanceTextView = view.findViewById<TextView>(R.id.sender_closing_balance)
        val receiverOpeningBalanceTextView = view.findViewById<TextView>(R.id.receiver_opening_balance)
        val receiverClosingBalanceTextView = view.findViewById<TextView>(R.id.receiver_closing_balance)
        val orderStatusTextView = view.findViewById<TextView>(R.id.order_status)
        val transactionId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_ID))
        val transactionTime = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_DATE_TIME))
        val senderId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_SENDER_ID))
        val receiverId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_RECEIVER_ID))
        val senderOpeningBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_SENDER_OPENING_BALANCE))
        val senderClosingBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_SENDER_CLOSING_BALANCE))
        val receiverOpeningBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_RECEIVER_OPENING_BALANCE))
        val receiverClosingBalance = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_RECEIVER_CLOSING_BALANCE))
        val order_status = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_ORDER_STATUS))
        transactionIdTextView.text = "Transaction ID: \t$transactionId"
        transactionTimeTextView.text = "Transaction Time: \t$transactionTime"
        senderIdTextView.text = "Sender ID : \t\t$senderId"
        receiverIdTextView.text = "Receiver ID : \t\t$receiverId"
        senderOpeningBalanceTextView.text = "Sender Opening Balance : $senderOpeningBalance"
        senderClosingBalanceTextView.text = "Sender Closing Balance : $senderClosingBalance"
        receiverOpeningBalanceTextView.text = "Receiver Opening Balance : $receiverOpeningBalance"
        receiverClosingBalanceTextView.text = "Receiver Closing Balance : $receiverClosingBalance"
        orderStatusTextView.text = order_status
    }
}