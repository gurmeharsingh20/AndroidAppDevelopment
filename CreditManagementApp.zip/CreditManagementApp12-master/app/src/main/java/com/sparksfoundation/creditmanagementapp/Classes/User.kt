package com.sparksfoundation.creditmanagementapp.Classes

class User {
    private var id = 0
    var name: String? = null
    var email: String? = null
    var currentCredits = 0

    //constructors
    constructor() {}
    constructor(id: Int, name: String?, email: String?, currentCredits: Int) {
        this.id = id
        this.name = name
        this.email = email
        this.currentCredits = currentCredits
    }

    //setters
    fun setId(id: Int) {
        this.id = id
    }

    //getters
    fun getId(): Long {
        return id.toLong()
    }

}